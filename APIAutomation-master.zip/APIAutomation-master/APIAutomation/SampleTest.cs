﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json;
using System;
using System.IO;
using System.Net;

namespace APIAutomation
{
    [TestClass]
    public class SampleTest
    {
        [TestMethod]
        public void TestGetUsers()
        {
            string jsonResponse;
            string baseUrl = "https://reqres.in/api/";
            string route = "users/2";
            HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(baseUrl + route);
            httpWebRequest.Method = "GET";
            HttpWebResponse response = (HttpWebResponse)httpWebRequest.GetResponse();
            Stream stream = response.GetResponseStream();
            using (StreamReader reader = new StreamReader(stream))
            {
                jsonResponse = reader.ReadToEnd();
            }
            var _apiResponse = JsonConvert.DeserializeObject<SingleUserResponseObject>(jsonResponse);
            Assert.IsTrue(_apiResponse.data.id.Equals(2));
        }

        [TestMethod]
        public void TestCreateUser()
        {
            string jsonResponse;
            var reqObject = new UsersRequestObject();
            reqObject.name = "morpheus";
            reqObject.job = "leader";

            string request = JsonConvert.SerializeObject(reqObject);
            string baseUrl = "https://reqres.in/api/";
            string route = "users";
            HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(baseUrl + route);
            httpWebRequest.Method = "POST";
            httpWebRequest.ContentType = "application/json";
            using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
            {
                streamWriter.Write(request);
            }
            HttpWebResponse httpresponse = (HttpWebResponse)httpWebRequest.GetResponse();
            Stream stream = httpresponse.GetResponseStream();
            using (StreamReader reader = new StreamReader(stream))
            {
                jsonResponse = reader.ReadToEnd();
            }
            var apiResponse = JsonConvert.DeserializeObject<UsersResponseObject>(jsonResponse);
            Assert.IsTrue(apiResponse.name.Equals("morpheus") && apiResponse.job.Equals("leader"));
        }
    }

    public class SingleUserResponseObject
    {
        public Data data { get; set; }
        public Ad ad { get; set; }
    }

    public class Data
    {
        public int id { get; set; }
        public string email { get; set; }
        public string first_name { get; set; }
        public string last_name { get; set; }
        public string avatar { get; set; }
    }

    public class Ad
    {
        public string company { get; set; }
        public string url { get; set; }
        public string text { get; set; }
    }

    public class UsersRequestObject
    {
        public string name { get; set; }
        public string job { get; set; }
    }
    public class UsersResponseObject
    {
        public string name { get; set; }
        public string job { get; set; }
        public string id { get; set; }
        public DateTime createdAt { get; set; }
    }
}
